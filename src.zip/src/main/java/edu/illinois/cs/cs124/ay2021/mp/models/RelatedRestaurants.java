package edu.illinois.cs.cs124.ay2021.mp.models;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RelatedRestaurants {
  private Map<String, Map<String, Integer>> restaurantRelation = new HashMap<>();
  public RelatedRestaurants(final List<Restaurant> restaurants, final List<Preference> preferences) {
    Map<String, Integer> toPut;
    for (Restaurant r : restaurants) {
      toPut = new HashMap<>();
      for (Preference pre : preferences) {
        if (pre.contain(r.getId())) {
          for (String match : pre.getRestaurantIDs()) {
            if (!match.equals(r.getId()) && contain(restaurants, match)) {
              if (toPut.get(match) == null) {
                toPut.put(match, 1);
              } else {
                toPut.put(match, toPut.get(match) + 1);
              }
            }
          }
        }
      }
      restaurantRelation.put(r.getId(), toPut);
    }
  }

  public boolean contain(final List<Restaurant> res, final String str) {
    boolean ans = false;
    for (Restaurant r : res) {
      if (r.getId().equals(str)) {
        ans = true;
      }
    }
    return ans;
  }

  public Map<String, Integer> getRelated(final String restaurantID) {
    Map<String, Integer> returnMap = restaurantRelation.get(restaurantID);
    if (returnMap != null) {
      return returnMap;
    } else {
      return new HashMap<>();
    }
  }
}
