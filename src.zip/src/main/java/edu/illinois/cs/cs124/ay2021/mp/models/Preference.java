package edu.illinois.cs.cs124.ay2021.mp.models;

//MP2 Part 2
public class Preference {
  public Preference() {}

  private String id;

  public String getID() {
    return id;
  }

  private String[] restaurantIDs;

  public String[] getRestaurantIDs() {
    return restaurantIDs;
  }

  public boolean contain(final String ids) {
    for (String str : restaurantIDs) {
      if (ids.equals(str)) {
        return true;
      }
    }
    return false;
  }
}
