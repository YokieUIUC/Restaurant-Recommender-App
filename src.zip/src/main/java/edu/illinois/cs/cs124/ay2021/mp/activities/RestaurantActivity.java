package edu.illinois.cs.cs124.ay2021.mp.activities;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;


import edu.illinois.cs.cs124.ay2021.mp.application.EatableApplication;
import edu.illinois.cs.cs124.ay2021.mp.databinding.ActivityRestaurantBinding;
import edu.illinois.cs.cs124.ay2021.mp.R;
import edu.illinois.cs.cs124.ay2021.mp.models.Restaurant;

public class RestaurantActivity extends AppCompatActivity {
  private ActivityRestaurantBinding binding;

  @Override
  protected void onCreate(@Nullable final Bundle unused) {
    super.onCreate(unused);

    EatableApplication e = (EatableApplication) getApplication();
    Intent startedIntent = getIntent();
    String id = startedIntent.getExtras().get("id").toString();
    binding = DataBindingUtil.setContentView(this, R.layout.activity_restaurant);
    Restaurant res = e.getClient().getRestaurantForID(id);
    binding.name.setText(res.getName() + " " + res.getCuisine());
  }
}
